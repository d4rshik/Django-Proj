from django.contrib.auth import login, authenticate
from django.shortcuts import render, redirect
from django.views.decorators.csrf import ensure_csrf_cookie
from django.core.mail import send_mail

@ensure_csrf_cookie

def message(request):


    send_mail(
        'Notification',
        'How are you',
        'd4rshik@gmail.com',
        ['fasionps@gmail.com.com'],
        fail_silently=False,
    )
    return render(request,'home/message.html')

def blog(request):
    return render(request,'home/blog.html')
